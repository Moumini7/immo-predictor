"""
app.py – Point d'entrée principal de l'application Immo Predictor
"""

import streamlit as st

# ── Configuration globale de la page ──────────────────────────────────────────
st.set_page_config(
    page_title="Immo Predictor",
    page_icon="🏠",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ── CSS personnalisé ───────────────────────────────────────────────────────────
st.markdown("""
<style>
    .main-title {
        font-size: 2.8rem;
        font-weight: 800;
        color: #1f3c88;
        margin-bottom: 0;
    }
    .sub-title {
        font-size: 1.1rem;
        color: #555;
        margin-bottom: 2rem;
    }
    .card {
        background: #f8f9ff;
        border-left: 5px solid #1f3c88;
        border-radius: 8px;
        padding: 1.2rem 1.5rem;
        margin-bottom: 1rem;
    }
    .card h3 { color: #1f3c88; margin-bottom: 0.3rem; }
    .card p  { color: #444; margin: 0; }
    .badge {
        display: inline-block;
        background: #1f3c88;
        color: white;
        padding: 2px 10px;
        border-radius: 12px;
        font-size: 0.8rem;
        margin-right: 5px;
    }
</style>
""", unsafe_allow_html=True)

# ── Contenu de la page d'accueil ───────────────────────────────────────────────
st.markdown('<p class="main-title">🏠 Immo Predictor</p>', unsafe_allow_html=True)
st.markdown(
    '<p class="sub-title">Valorisation et Diagnostic Intelligent de Biens Immobiliers</p>',
    unsafe_allow_html=True
)

st.divider()

# Description du projet
col1, col2 = st.columns([2, 1])

with col1:
    st.markdown("## 📌 À propos du projet")
    st.markdown("""
    **Immo Predictor** est une plateforme de Machine Learning appliquée à l'immobilier.
    Elle permet deux types d'analyses :

    - 🎯 **Prédire le prix de vente** d'une maison (Régression)
    - 🏷️ **Classifier automatiquement le type** d'un bien immobilier (Classification)

    Le modèle est entraîné sur le célèbre dataset **House Prices** (Ames, Iowa - Kaggle),
    qui contient **1 460 maisons** décrites par **80 variables** (surface, qualité, localisation...).
    """)

with col2:
    st.markdown("## 📊 Dataset")
    st.info("""
    **Source** : Kaggle – House Prices  
    **Maisons** : 1 460  
    **Variables** : 80  
    **Ville** : Ames, Iowa (USA)
    """)

st.divider()

# Les 4 fonctionnalités
st.markdown("## 🗺️ Fonctionnalités disponibles")

c1, c2 = st.columns(2)

with c1:
    st.markdown("""
    <div class="card">
        <h3>📊 F1 · Analyse Exploratoire (EDA)</h3>
        <p>Distribution des prix, corrélations, statistiques descriptives, valeurs manquantes.</p>
        <span class="badge">Visualisation</span><span class="badge">Statistiques</span>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("""
    <div class="card">
        <h3>📈 F2 · Régression – Prédiction du Prix</h3>
        <p>Entraînement de Decision Tree et Random Forest. Comparaison des métriques MAE, RMSE, R².</p>
        <span class="badge">Decision Tree</span><span class="badge">Random Forest</span>
    </div>
    """, unsafe_allow_html=True)

with c2:
    st.markdown("""
    <div class="card">
        <h3>🏷️ F3 · Classification – Type de Bâtiment</h3>
        <p>SVM et Random Forest pour classifier BldgType. Accuracy, F1-score, matrice de confusion.</p>
        <span class="badge">SVM</span><span class="badge">Random Forest</span>
    </div>
    """, unsafe_allow_html=True)

    st.markdown("""
    <div class="card">
        <h3>🔮 F4 · Prédiction Interactive</h3>
        <p>Entrez les caractéristiques d'une maison et obtenez instantanément le prix estimé et le type prédit.</p>
        <span class="badge">Temps réel</span><span class="badge">Interactive</span>
    </div>
    """, unsafe_allow_html=True)

st.divider()

# Instructions de navigation
st.markdown("## 🧭 Comment naviguer ?")
st.markdown("""
Utilisez le **menu latéral gauche** (sidebar) pour accéder à chaque fonctionnalité.  
Les modèles sont entraînés **automatiquement au premier chargement** et mis en cache
pour des performances optimales.
""")

st.success("👈 Commencez par **F1 · EDA** pour explorer les données !")
